package com.sky.contentversionmanager.presentation.ui.intro

sealed class VersionCompareState {
    data class ShowContentUpdate(val filename: String) : VersionCompareState()

    sealed class GetVersionFailure : VersionCompareState() {
        data object Local : GetVersionFailure()

        data object Remote : GetVersionFailure()
    }
}