package com.ibk.android.mbs.presentation.common

import java.util.concurrent.atomic.AtomicBoolean

internal class EventWrapper<T>(val value: T) {

    private val isConsumed: AtomicBoolean = AtomicBoolean(false)

    fun markConsumed(): Boolean = isConsumed.getAndSet(true)
}