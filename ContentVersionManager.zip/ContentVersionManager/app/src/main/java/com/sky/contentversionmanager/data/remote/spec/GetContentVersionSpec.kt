package com.sky.contentversionmanager.data.remote.spec

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class RemoteContentVersion(
    @SerialName("oldVersion")
    val oldVersion: Int? = null,

    @SerialName("newerVersion")
    val newerVersion: Int? = null
)