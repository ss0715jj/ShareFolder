package com.sky.contentversionmanager.data.remote

import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import com.sky.contentversionmanager.Constant
import kotlinx.serialization.json.Json
import okhttp3.MediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.scalars.ScalarsConverterFactory
import java.util.concurrent.TimeUnit

object NetworkServiceBuilder {

    private val customJson = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        isLenient = true
        coerceInputValues = true
    }

    fun createHttpClient(timeoutMills: Long): OkHttpClient {
        return OkHttpClient.Builder().apply {
            connectTimeout(timeoutMills, TimeUnit.MILLISECONDS)
            writeTimeout(timeoutMills, TimeUnit.MILLISECONDS)
            readTimeout(timeoutMills, TimeUnit.MILLISECONDS)
        }.build()
    }

    fun buildRetrofit(baseUrl: String, client: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addCallAdapterFactory(NetworkCallAdapterFactory())
            .addConverterFactory(ScalarsConverterFactory.create())
            .addConverterFactory(customJson.asConverterFactory(MediaType.get("application/json")))
            .build()
    }

    inline fun <reified T> buildService(
        baseUrl: String? = Constant.BASE_URL,
        timeoutMills: Long = Constant.DEFAULT_HTTP_TIMEOUT_MILLIS
    ): T {
        return buildRetrofit(
            baseUrl = baseUrl.orEmpty(),
            client = createHttpClient(timeoutMills)
        ).create(T::class.java)
    }
}