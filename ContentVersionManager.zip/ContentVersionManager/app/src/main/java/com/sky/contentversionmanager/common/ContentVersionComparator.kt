package com.sky.contentversionmanager.common

import com.sky.contentversionmanager.domain.entity.ContentVersion

class ContentVersionComparator(
    private val versionCompare: ContentVersionCompare
) {

    fun compare(localContentVersion: ContentVersion, remoteContentVersion: ContentVersion) {
        versionCompare.compare(localContentVersion, remoteContentVersion)
    }
}