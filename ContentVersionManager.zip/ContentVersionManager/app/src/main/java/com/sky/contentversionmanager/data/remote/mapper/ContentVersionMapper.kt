package com.sky.contentversionmanager.data.remote.mapper

import com.sky.contentversionmanager.data.remote.spec.RemoteContentVersion
import com.sky.contentversionmanager.domain.entity.ContentVersion

object ContentVersionMapper {
    fun toContentVersion(remoteContentVersion: RemoteContentVersion): ContentVersion {
        val oldVersion = remoteContentVersion.oldVersion ?: 1
        val newerVersion = remoteContentVersion.newerVersion ?: 1
        return ContentVersion(oldVersion = oldVersion, newerVersion = newerVersion)
    }
}