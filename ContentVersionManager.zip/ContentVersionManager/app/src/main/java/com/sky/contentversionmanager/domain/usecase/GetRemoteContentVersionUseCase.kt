package com.sky.contentversionmanager.domain.usecase

import com.sky.contentversionmanager.domain.entity.ContentVersion
import com.sky.contentversionmanager.domain.entity.DataResult
import com.sky.contentversionmanager.domain.repository.GetContentVersionRepository
import javax.inject.Inject

class GetRemoteContentVersionUseCase @Inject constructor(
    private val repository: GetContentVersionRepository
) {
    suspend operator fun invoke(): DataResult<ContentVersion> {
        return repository.getRemoteContentVersion()
    }
}