package com.sky.contentversionmanager.presentation.ui.intro

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.sky.contentversionmanager.R
import com.sky.contentversionmanager.data.local.spec.LocalContentVersion
import com.sky.contentversionmanager.databinding.ActivityIntroBinding
import com.sky.contentversionmanager.presentation.common.extension.collectRepeatOnStarted
import com.sky.contentversionmanager.presentation.common.extension.safeEdge
import com.sky.contentversionmanager.presentation.ui.BaseActivity
import com.sky.contentversionmanager.presentation.ui.main.MainViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import timber.log.Timber

@AndroidEntryPoint
class IntroActivity : BaseActivity<ActivityIntroBinding>() {

    override val layoutId: Int = R.layout.activity_intro
    private val viewModel: IntroViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding.main.safeEdge()

        collectData()

        viewModel.compareContentVersion()
    }

    private fun collectData() {
        viewModel.versionCompareEvent.collectRepeatOnStarted(this) { result ->

        }
    }
}