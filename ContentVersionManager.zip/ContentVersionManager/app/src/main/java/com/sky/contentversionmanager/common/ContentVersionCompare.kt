package com.sky.contentversionmanager.common

import com.sky.contentversionmanager.domain.entity.ContentVersion

interface ContentVersionCompare {
    /**
     * 버전 비교
     */
    fun compare(localVersion: ContentVersion, remoteVersion: ContentVersion)
}