package com.sky.contentversionmanager.domain.entity

data class ContentVersion(
    val oldVersion: Int,
    val newerVersion: Int
)
