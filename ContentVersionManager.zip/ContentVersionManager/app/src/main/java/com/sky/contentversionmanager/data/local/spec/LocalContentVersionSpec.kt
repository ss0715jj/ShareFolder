package com.sky.contentversionmanager.data.local.spec

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class LocalContentVersion(
    @SerialName("oldVersion")
    val oldVersion: Int = 1,

    @SerialName("newerVersion")
    val newerVersion: Int = 1
)