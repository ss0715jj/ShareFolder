package com.sky.contentversionmanager.domain.entity

sealed class DataResult<out T> {
    class Success<T>(val data: T) : DataResult<T>()

    class Error(val exception: Exception) : DataResult<Nothing>()
}