package com.sky.contentversionmanager.data.remote.service

const val GET_CONTENT_VERSION = "api/getContentVersion"