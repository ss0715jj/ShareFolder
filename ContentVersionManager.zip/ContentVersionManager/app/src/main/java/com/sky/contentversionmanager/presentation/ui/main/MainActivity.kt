package com.sky.contentversionmanager.presentation.ui.main

import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.sky.contentversionmanager.R
import com.sky.contentversionmanager.databinding.ActivityMainBinding
import com.sky.contentversionmanager.presentation.common.extension.safeEdge
import com.sky.contentversionmanager.presentation.ui.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : BaseActivity<ActivityMainBinding>() {

    override val layoutId: Int = R.layout.activity_main
    private val mainViewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding.main.safeEdge()


    }
}