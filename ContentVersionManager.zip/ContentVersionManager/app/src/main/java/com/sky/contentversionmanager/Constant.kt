package com.sky.contentversionmanager

object Constant {
    const val DEFAULT_HTTP_TIMEOUT_MILLIS: Long = 30_000

    const val BASE_URL = "https://m.naver.com"
}