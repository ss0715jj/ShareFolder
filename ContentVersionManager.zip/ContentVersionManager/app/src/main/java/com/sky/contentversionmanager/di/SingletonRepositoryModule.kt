package com.sky.contentversionmanager.di

import com.sky.contentversionmanager.data.repository.GetContentVersionRepositoryImpl
import com.sky.contentversionmanager.domain.repository.GetContentVersionRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
abstract class SingletonRepositoryModule {

    @Binds
    abstract fun bindGetContentVersionRepository(impl: GetContentVersionRepositoryImpl): GetContentVersionRepository
}