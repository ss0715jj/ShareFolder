package com.sky.contentversionmanager.data.remote

sealed class NetworkResponse<out T> {
    class Success<BODY, T>(val body: BODY) : NetworkResponse<T>()

    class Error(val exception: Exception) : NetworkResponse<Nothing>()
}