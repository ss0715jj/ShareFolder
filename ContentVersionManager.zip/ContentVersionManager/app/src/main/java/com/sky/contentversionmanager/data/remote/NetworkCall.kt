package com.sky.contentversionmanager.data.remote

import kotlinx.serialization.SerializationException
import okhttp3.Request
import okio.Timeout
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import timber.log.Timber
import java.io.IOException

class NetworkCall<T>(
    private val delegate: Call<T>
) : Call<NetworkResponse<T>> {
    override fun clone() = NetworkCall(delegate.clone())

    override fun execute(): Response<NetworkResponse<T>> {
        throw UnsupportedOperationException("ApiResponseCall doesn't support execute")
    }

    override fun isExecuted() = delegate.isExecuted

    override fun cancel() = delegate.cancel()

    override fun isCanceled() = delegate.isCanceled

    override fun request(): Request = delegate.request()

    override fun timeout(): Timeout = delegate.timeout()

    override fun enqueue(callback: Callback<NetworkResponse<T>>) {
        return delegate.enqueue(object : Callback<T> {
            override fun onResponse(call: Call<T>, response: Response<T>) {
                if (!response.isSuccessful) {
                    val errorBody = response.errorBody()
                    if (errorBody == null) {
                        callbackError(IllegalStateException("The error response body is empty!"))
                    } else {
                        callbackError(IllegalStateException("HTTP ${response.code()} ${errorBody.string()}"))
                    }

                    return
                }

                val body = response.body()
                if (body == null) {
                    callbackError(IllegalStateException("The response body is empty!"))
                    return
                }

                callback.onResponse(this@NetworkCall, Response.success(NetworkResponse.Success(body)))
            }

            override fun onFailure(call: Call<T>, t: Throwable) {
                val exception = when (t) {
                    is IOException -> {
                        IOException(t.message.toString())
                    }
                    is SerializationException -> {
                        IllegalStateException(t.message.toString())
                    }
                    else -> {
                        IllegalStateException("Unknown")
                    }
                }
                callbackError(exception)
            }

            fun callbackError(exception: Exception) {
                Timber.e(exception, "HttpLog")
                callback.onResponse(this@NetworkCall, Response.success(NetworkResponse.Error(exception)))
            }
        })
    }
}