package com.sky.contentversionmanager.data.local

import com.sky.contentversionmanager.data.local.spec.LocalContentVersion
import com.sky.contentversionmanager.domain.entity.ContentVersion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import timber.log.Timber
import java.io.File

class LocalAppCacheStorage(private val cacheDir: File) {

    suspend fun createLocalContentVersionInfoFile(json: String = DEFAULT_LOCAL_CONTENT_VERSION_JSON): File {
        return withContext(Dispatchers.IO) {
            val dir = cacheDir.resolve(LOCAL_CONTENT_VERSION_DIR_NAME)
            if (!dir.exists()) {
                if (!dir.mkdir()) throw IllegalStateException("dir create fail")
            }

            val file = dir.resolve(LOCAL_CONTENT_VERSION_FILE_NAME)
            if (!file.exists()) {
                if (!file.createNewFile()) throw IllegalStateException("file create fail")
                file.writeText(json)
            }

            return@withContext file
        }
    }

    suspend fun readLocalContentVersionInfoFile(): LocalContentVersion {
        return withContext(Dispatchers.IO) {
            val file = createLocalContentVersionInfoFile()

            val json = file.readText()
            Timber.d("LocalContentVersion json : $json")

            Json.decodeFromString<LocalContentVersion>(json)
        }
    }

    suspend fun updateLocalContentVersionInfo(contentVersion: ContentVersion): Boolean {
        return withContext(Dispatchers.IO) {
            if (deleteLocalContentVersionInfoFile()) {
                Timber.e("")
                return@withContext false
            }

            val json = createLocalVersionInfoJson(contentVersion)
            createLocalContentVersionInfoFile(json)

            true
        }
    }

    suspend fun deleteLocalContentVersionInfoFile(): Boolean {
        return withContext(Dispatchers.IO) {
            val dir = cacheDir.resolve(LOCAL_CONTENT_VERSION_DIR_NAME)
            if (!dir.exists()) {
                Timber.e("")
                return@withContext false
            }

            val file = dir.resolve(LOCAL_CONTENT_VERSION_FILE_NAME)
            if (!file.exists()) {
                Timber.e("")
                return@withContext false
            }

            file.delete()
        }
    }

    private fun createLocalVersionInfoJson(contentVersion: ContentVersion): String {
        val localContentVersion = LocalContentVersion(
            oldVersion = contentVersion.oldVersion,
            newerVersion = contentVersion.newerVersion
        )

        val json = customJson.encodeToString(localContentVersion)
        Timber.d("created local content version json : $json")

        return json
    }

    companion object {
        private val customJson = Json {
            ignoreUnknownKeys = true
            encodeDefaults = true
            isLenient = true
            coerceInputValues = true
        }

        private const val LOCAL_CONTENT_VERSION_DIR_NAME = "contentVersion"
        private const val LOCAL_CONTENT_VERSION_FILE_NAME = "version.json"
        private val DEFAULT_LOCAL_CONTENT_VERSION_JSON = customJson.encodeToString(LocalContentVersion())
    }
}