package com.sky.contentversionmanager.presentation.ui.intro

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ibk.android.mbs.presentation.common.MutableEventFlow
import com.ibk.android.mbs.presentation.common.asEventFlow
import com.sky.contentversionmanager.common.ContentVersionComparator
import com.sky.contentversionmanager.common.DefaultContentVersionCompare
import com.sky.contentversionmanager.domain.entity.ContentVersion
import com.sky.contentversionmanager.domain.entity.DataResult
import com.sky.contentversionmanager.domain.usecase.GetLocalContentVersionUseCase
import com.sky.contentversionmanager.domain.usecase.GetRemoteContentVersionUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class IntroViewModel @Inject constructor(
    private val getLocalContentVersionUseCase: GetLocalContentVersionUseCase,
    private val getRemoteContentVersionUseCase: GetRemoteContentVersionUseCase,
) : ViewModel() {

    private val _versionCompareEvent: MutableEventFlow<VersionCompareState> = MutableEventFlow()
    val versionCompareEvent = _versionCompareEvent.asEventFlow()

    fun compareContentVersion() {
        viewModelScope.launch {
            val localContentVersion = getLocalContentVersion()
            val remoteContentVersion = getRemoteContentVersion()

            if (localContentVersion == null) {
                _versionCompareEvent.emit(VersionCompareState.GetVersionFailure.Local)
                return@launch
            }

            if (remoteContentVersion == null) {
                _versionCompareEvent.emit(VersionCompareState.GetVersionFailure.Remote)
                return@launch
            }

            doCompareContentVersion(localContentVersion, remoteContentVersion)

//            Timber.d("localContentVersion : $localContentVersion")
//            Timber.d("remoteContentVersion : $remoteContentVersion")
        }
    }

    private suspend fun getLocalContentVersion(): ContentVersion? {
        return when (val result = getLocalContentVersionUseCase()) {
            is DataResult.Success -> result.data

            is DataResult.Error -> null
        }
    }

    private suspend fun getRemoteContentVersion(): ContentVersion? {
        return when (val result = getRemoteContentVersionUseCase()) {
            is DataResult.Success -> result.data

            is DataResult.Error -> null
        }
    }

    private suspend fun doCompareContentVersion(
        localContentVersion: ContentVersion,
        remoteContentVersion: ContentVersion
    ): VersionCompareState {
        val comparator = ContentVersionComparator(DefaultContentVersionCompare())
        comparator.compare()
        return VersionCompareState.ShowContentUpdate("")
    }
}