package com.sky.contentversionmanager.common

import com.sky.contentversionmanager.domain.entity.ContentVersion

class DefaultContentVersionCompare : ContentVersionCompare {
    override fun compare(localVersion: ContentVersion, remoteVersion: ContentVersion) {

    }
}