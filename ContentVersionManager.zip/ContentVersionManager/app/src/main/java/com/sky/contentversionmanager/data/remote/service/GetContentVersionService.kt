package com.sky.contentversionmanager.data.remote.service

import com.sky.contentversionmanager.data.remote.NetworkResponse
import com.sky.contentversionmanager.data.remote.spec.RemoteContentVersion
import retrofit2.http.GET

interface GetContentVersionService {

    @GET(GET_CONTENT_VERSION)
    suspend fun getContentVersion(): NetworkResponse<RemoteContentVersion>
}