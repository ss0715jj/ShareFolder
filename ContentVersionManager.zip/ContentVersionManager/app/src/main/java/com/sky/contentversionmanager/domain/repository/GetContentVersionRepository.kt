package com.sky.contentversionmanager.domain.repository

import com.sky.contentversionmanager.domain.entity.ContentVersion
import com.sky.contentversionmanager.domain.entity.DataResult

interface GetContentVersionRepository {

    suspend fun getRemoteContentVersion(): DataResult<ContentVersion>

    suspend fun getLocalContentVersion(): DataResult<ContentVersion>
}