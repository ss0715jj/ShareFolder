package com.sky.contentversionmanager.data.repository

import android.content.Context
import com.sky.contentversionmanager.data.local.LocalAppCacheStorage
import com.sky.contentversionmanager.data.remote.NetworkResponse
import com.sky.contentversionmanager.data.remote.NetworkServiceBuilder
import com.sky.contentversionmanager.data.remote.mapper.ContentVersionMapper
import com.sky.contentversionmanager.data.remote.service.GetContentVersionService
import com.sky.contentversionmanager.data.remote.spec.RemoteContentVersion
import com.sky.contentversionmanager.domain.entity.ContentVersion
import com.sky.contentversionmanager.domain.entity.DataResult
import com.sky.contentversionmanager.domain.repository.GetContentVersionRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import timber.log.Timber
import javax.inject.Inject

class GetContentVersionRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : GetContentVersionRepository {

    private val service = NetworkServiceBuilder.buildService<GetContentVersionService>()
    private val localAppCacheStorage = LocalAppCacheStorage(context.cacheDir)

    override suspend fun getRemoteContentVersion(): DataResult<ContentVersion> {
        return when (val result = service.getContentVersion()) {
            is NetworkResponse.Success<*, *> -> {
                val contentVersion =
                    ContentVersionMapper.toContentVersion(result.body as RemoteContentVersion)
                DataResult.Success(contentVersion)
            }

            is NetworkResponse.Error -> {
                DataResult.Error(exception = result.exception)
            }
        }
    }

    override suspend fun getLocalContentVersion(): DataResult<ContentVersion> {
        return try {
            val versionInfoFile = localAppCacheStorage.readLocalContentVersionInfoFile()
            val contentVersion = ContentVersion(
                oldVersion = versionInfoFile.oldVersion,
                newerVersion = versionInfoFile.newerVersion
            )
            DataResult.Success(contentVersion)
        } catch (e: IllegalStateException) {
            Timber.e(e)
            DataResult.Error(exception = e)
        }
    }
}