import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Base64;
//import java.util.Base64.Decoder;
import java.util.Base64.Encoder;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import com.kisa.seed.cbc.KISA_SEED_CBC;

public class password_encrypt {

	public static void main(String[] args) {
		//개발
		String resulturl = "http://192.168.250.141/authentication/idpw/getAccountStatusApi";
		//운영
		//String resulturl = "http://nsso.ibk.co.kr/authentication/idpw/getAccountStatusApi";
		
		System.out.println("====================================");
		System.out.println("<< Password >>");
		try {

			String id = "042490"; // 사용자 아이디 (6 자릿수 ex) 012345 / S92522)
			System.out.println(">>>>>>>>> id : " + id);

			String pw = "ibk!1234"; // 비밀번호 평문
			System.out.println(">>>>>>>>> pw : " + pw);
			String agentId = "276"; //SSO 담당자에게 서비스 ID를 별도로 받아햡니다.

			byte[] encryptData = encrypt(pw); // 비밀번호 암호화 진행
			String encrypt = new String(encryptData, "utf-8");
			System.out.println("encrypt:" + encrypt); // 암호화된 비밀번호

			// pw = decrypt(encryptData); // 비밀번호 암호화를 복호화
			// System.out.println("decrypt:" + pw);

			JSONObject jsonObj = new JSONObject();
			jsonObj.put("id", id);
			jsonObj.put("pw", encrypt);
			jsonObj.put("agentId", agentId);

			BufferedReader rd = sendHttpRequest("POST", resulturl, jsonObj.toJSONString());

			// Parse HTTP Response
			if (rd != null) {
				String rsponseData = "";
				String readData = null;
				while ((readData = rd.readLine()) != null) {

					rsponseData += readData;
				}

				JSONParser parser = new JSONParser();
				JSONObject jsonObject = (JSONObject) parser.parse(rsponseData);

				System.out.println(jsonObject);

				String resultCode = (String) jsonObject.get("resultCode");
				String resultMessage = (String) jsonObject.get("resultMessage");
				String resultData = (String) jsonObject.get("resultData");

				System.out.println("====Auth Type general=====");
				System.out.println("resultCode : " + resultCode);
				System.out.println("resultMessage : " + resultMessage);
				System.out.println("resultData : " + resultData);

			}

			rd.close();

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("====================================");
		}
	}

	public static byte[] encrypt(String str) {
		String CHARSET = "utf-8";
		String PBUserKey = "56455259474F4F4449424B";
		String DEFAULT_IV = "49424B5F50454E5441";

		byte pbUserKey[] = PBUserKey.getBytes();
		byte bszIV[] = DEFAULT_IV.getBytes();

		byte[] enc = null;
		try {

			// 암호화 호출
			enc = KISA_SEED_CBC.SEED_CBC_Encrypt(pbUserKey, bszIV, str.getBytes(CHARSET), 0,
					str.getBytes(CHARSET).length);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		Encoder encoder = Base64.getEncoder();
		byte[] encArray = encoder.encode(enc);

		return encArray;
	}

	/*
	 * public static String decrypt(byte[] str) {
	 * 
	 * Decoder decoder = Base64.getDecoder(); byte[] enc = decoder.decode(str);
	 * 
	 * String result = ""; byte[] dec = null;
	 * 
	 * try { dec = KISA_SEED_CBC.SEED_CBC_Decrypt(pbUserKey, bszIV, enc, 0,
	 * enc.length); result = new String(dec, CHARSET);
	 * 
	 * } catch (UnsupportedEncodingException e) { e.printStackTrace(); }
	 * 
	 * return result; }
	 */

	public static BufferedReader sendHttpRequest(String requestMode, String urlString, String PostData) {

		URL url = null;
		BufferedReader rd = null;

		URLConnection con;
		try {

			url = new URL(urlString);
			con = (HttpURLConnection) url.openConnection();
			System.out.println("PostData : " + PostData);

			con.setReadTimeout(50000);
			con.setDoOutput(true);
			con.setRequestProperty("User-Agent", "Mozilla/5.0");
			con.setRequestProperty("Content-Type", "application/json");
			con.setRequestProperty("Accept-Language", "ko-KR");
			con.setRequestProperty("Content-Length", String.valueOf(PostData.length()));
			con.setDoOutput(true);

			DataOutputStream wr;
			wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(PostData);
			wr.flush();
			wr.close();

			rd = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));

		} catch (MalformedURLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rd;
	}
}
